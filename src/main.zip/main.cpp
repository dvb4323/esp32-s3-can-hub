#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include "driver/twai.h"

// ================== CHÂN CAN ==================
#ifndef CAN_TX_PIN
#define CAN_TX_PIN 47
#endif

#ifndef CAN_RX_PIN
#define CAN_RX_PIN 48
#endif

static const gpio_num_t CAN_TX_GPIO = (gpio_num_t)CAN_TX_PIN;
static const gpio_num_t CAN_RX_GPIO = (gpio_num_t)CAN_RX_PIN;

// ================== WIFI AP ==================
const char *AP_SSID = "TCOM_CAN";
const char *AP_PASS = "67896789";

// ================== CAN ==================
#define MAX_ROWS       40
#define MAX_RX_ROWS    120
#define MAX_AUTO_JOBS  8

WebServer server(80);

bool canReady = false;
uint32_t currentBitrate = 500;

uint32_t rxTotal = 0;
uint32_t txTotal = 0;

// ================== DATA STRUCT ==================
struct CanRow {
  bool used;
  bool ext;
  bool rtr;
  uint32_t id;
  uint8_t len;
  uint8_t data[8];
  uint32_t cycleMs;
  uint32_t lastMs;
  uint32_t count;
};

struct TxJob {
  bool used;
  int rowIndex;
  uint32_t intervalMs;
  uint32_t nextMs;
};

CanRow rxRows[MAX_RX_ROWS];
CanRow txRows[MAX_ROWS];
TxJob txJobs[MAX_AUTO_JOBS];

// rxRows được ghi từ task nhận CAN (core 0) và đọc từ web server (core 1)
SemaphoreHandle_t rxMutex = nullptr;
volatile bool rxTaskBusy = false;

// ================== HTML ==================
static const char INDEX_HTML[] PROGMEM = R"HTML(
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>ESP32 CAN Monitor</title>

  <style>
    body {
      margin: 0;
      font-family: Segoe UI, Arial, sans-serif;
      background: #f4f5f6;
      color: #222;
      font-size: 13px;
    }

    .topbar {
      height: 30px;
      background: white;
      border-bottom: 1px solid #d8dde1;
      display: flex;
      align-items: flex-end;
      gap: 16px;
      padding: 0 8px;
    }

    .tab {
      padding-bottom: 6px;
      color: #333;
    }

    .tab.active {
      border-bottom: 1px solid #333;
    }

    .status {
      margin-left: auto;
      margin-bottom: 5px;
      padding: 2px 8px;
      border-radius: 10px;
      background: #e7edf2;
      color: #334;
      font-size: 12px;
    }

    .status.ok {
      background: #dff3e4;
      color: #126b2f;
    }

    .status.err {
      background: #fde3e3;
      color: #9a1d1d;
    }

    .page {
      padding: 10px 12px;
    }

    .settings {
      width: 320px;
      margin-bottom: 18px;
    }

    .settingsHead {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 8px;
      color: #333;
      font-size: 14px;
    }

    .settingsGrid {
      display: grid;
      grid-template-columns: 130px 1fr;
      gap: 9px 12px;
      align-items: center;
    }

    .settingsGrid label {
      color: #4e5862;
    }

    select, input {
      font-family: Segoe UI, Arial, sans-serif;
      font-size: 12px;
      box-sizing: border-box;
    }

    .settingsGrid select,
    .settingsGrid input {
      width: 150px;
      height: 24px;
      border: 1px solid #cfd5da;
      background: white;
      padding: 2px 5px;
    }

    .settingsGrid input:disabled,
    .settingsGrid select:disabled {
      background: #f0f0f0;
      color: #555;
    }

    .cfgMsg {
      grid-column: 1 / span 2;
      color: #61707c;
      font-size: 12px;
      margin-top: 2px;
    }

    .section {
      margin-top: 10px;
      margin-bottom: 28px;
    }

    .sectionHead {
      display: flex;
      align-items: center;
      gap: 14px;
      min-height: 30px;
      padding: 4px 0 4px 9px;
      color: #44505a;
      font-size: 14px;
      flex-wrap: wrap;
    }

    .title {
      min-width: 66px;
    }

    .toolbar {
      display: flex;
      align-items: center;
      gap: 8px;
      flex-wrap: wrap;
    }

    .toolBtn {
      border: none;
      background: transparent;
      cursor: pointer;
      font-size: 20px;
      color: #5a646c;
      height: 26px;
      line-height: 24px;
      padding: 0 2px;
    }

    .toolBtn:hover {
      color: #1f72b8;
    }

    .txCompose span {
      color: #66727b;
      font-size: 12px;
    }

    .txCompose input,
    .txCompose select {
      height: 24px;
      border: 1px solid #cfd5da;
      background: white;
      padding: 2px 5px;
    }

    .txCompose input:disabled {
      background: #f1f1f1;
      color: #777;
    }

    #txNewType {
      width: 78px;
    }

    #txNewId {
      width: 72px;
    }

    #txNewData {
      width: 220px;
      font-family: Consolas, monospace;
    }

    #txNewCycle {
      width: 72px;
    }

    .info {
      color: #66727b;
      font-size: 12px;
      margin-left: 8px;
    }

    .tablebox {
      border: 1px solid #bfc6cc;
      background: white;
      height: 226px;
      overflow: auto;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 12px;
    }

    th, td {
      border-right: 1px solid #edf0f3;
      border-bottom: 1px solid #edf0f3;
      padding: 0;
      text-align: left;
      white-space: nowrap;
      height: 25px;
    }

    th {
      position: sticky;
      top: 0;
      background: white;
      color: #000;
      font-weight: 600;
      z-index: 2;
      padding: 4px 6px;
    }

    td {
      padding: 2px 5px;
    }

    tr.selected {
      background: #e9f3ff;
    }

    .empty {
      color: #8a949b;
      text-align: center;
      padding: 36px;
    }

    .bytes {
      font-family: Consolas, monospace;
      letter-spacing: .3px;
    }

    .rowInput, .rowSelect {
      width: 100%;
      height: 23px;
      border: 1px solid transparent;
      background: transparent;
      font-size: 12px;
      box-sizing: border-box;
    }

    .rowInput:focus, .rowSelect:focus {
      border: 1px solid #8ab8e8;
      background: #fff;
      outline: none;
    }

    .rowInput:disabled, .rowSelect:disabled {
      background: #f1f1f1;
      color: #777;
    }

    .rowId {
      width: 78px;
    }

    .rowLen {
      width: 45px;
      text-align: center;
    }

    .rowCycle {
      width: 70px;
    }

    .rowData {
      min-width: 260px;
      font-family: Consolas, monospace;
    }

    .centerCell {
      text-align: center;
    }

    .footer {
      height: 24px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #69747c;
      font-size: 11px;
      border-top: 1px solid #d8dde1;
      background: white;
    }
  </style>
</head>

<body>
  <div class="topbar">
    <div class="tab active">Connect</div>
    <div class="tab">Trace</div>
    <div id="connect" class="status">Connecting...</div>
  </div>

  <div class="page">
    <div class="settings">
      <div class="settingsHead">
        <span>Settings</span>
        <button class="toolBtn" onclick="applyConfig()" title="Apply settings">↻</button>
        <span id="canState" class="status">CAN</span>
      </div>

      <div class="settingsGrid">
        <label>Mode:</label>
        <select id="mode" disabled>
          <option>CAN Classic</option>
        </select>

        <label>Clock Frequency:</label>
        <select id="clockFreq" disabled>
          <option>8 MHz</option>
        </select>

        <label>Database Entry:</label>
        <select id="dbEntry" onchange="userEditingConfig=true; setPresetUi(this.value)">
          <option value="125">125 kBit/s</option>
          <option value="250">250 kBit/s</option>
          <option value="500" selected>500 kBit/s</option>
          <option value="1000">1 MBit/s</option>
        </select>

        <label>Bit Rate [kbit/s]:</label>
        <input id="bitRate" value="500" disabled>

        <label>Bus Timing Register 0:</label>
        <input id="btr0" value="13" disabled>

        <label>Bus Timing Register 1:</label>
        <input id="btr1" value="2" disabled>

        <label>Sample Count:</label>
        <select id="sampleCount" disabled>
          <option>0</option>
        </select>

        <label>Prescaler:</label>
        <input id="prescaler" value="1" disabled>

        <div id="cfgMsg" class="cfgMsg">Đang dùng 500 kBit/s</div>
      </div>
    </div>

    <div class="section">
      <div class="sectionHead">
        <div class="title">Transmit</div>

        <div class="toolbar txCompose">
          <span>Type</span>
          <select id="txNewType" onchange="updateTxDraftDataState()">
            <option value="STD">STD</option>
            <option value="EXT">EXT</option>
            <option value="STD_RTR">STD RTR</option>
            <option value="EXT_RTR">EXT RTR</option>
          </select>

          <span>ID</span>
          <input id="txNewId" value="336">

          <span>Data</span>
          <input id="txNewData" value="01 00 00 00 00 00 00 00">

          <span>Cycle</span>
          <input id="txNewCycle" type="number" min="10" value="1000">

          <button class="toolBtn" onclick="addTxRow()" title="Thêm message TX từ phần đang chỉnh">＋</button>
          <button class="toolBtn" onclick="sendSelectedTx()" title="Gửi message đang chọn">↗</button>
          <button class="toolBtn" onclick="deleteSelectedTx()" title="Xóa message đang chọn">⌫</button>
          <button class="toolBtn" onclick="clearTx()" title="Clear TX">⋯</button>
        </div>

        <span id="txInfo" class="info">TX: 0</span>
      </div>

      <div class="tablebox">
        <table>
          <thead>
            <tr>
              <th style="width:70px">Type</th>
              <th style="width:95px">CAN-ID</th>
              <th style="width:55px">Length</th>
              <th style="width:110px">Name</th>
              <th>Data</th>
              <th style="width:80px">Cycle Time</th>
              <th style="width:45px">Auto</th>
              <th style="width:55px">Count</th>
            </tr>
          </thead>
          <tbody id="txBody">
            <tr><td colspan="8" class="empty">Chưa có message TX</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <div class="section">
      <div class="sectionHead">
        <div class="title">Receive</div>

        <div class="toolbar">
          <button class="toolBtn" onclick="clearRx()" title="Clear RX">⌫</button>
        </div>

        <span id="rxInfo" class="info">RX: 0</span>
        <span id="errInfo" class="info">ERR: 0</span>
      </div>

      <div class="tablebox">
        <table>
          <thead>
            <tr>
              <th style="width:70px">Type</th>
              <th style="width:95px">CAN-ID</th>
              <th style="width:55px">Length</th>
              <th style="width:110px">Name</th>
              <th>Data</th>
              <th style="width:80px">Cycle Time</th>
              <th style="width:55px">Count</th>
            </tr>
          </thead>
          <tbody id="rxBody">
            <tr><td colspan="7" class="empty">Chưa nhận được CAN frame</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="footer">
    ESP32-S3 CAN Webserver | IP: <span id="ip">192.168.4.1</span>
  </div>

<script>
let userEditingConfig = false;
let editingTx = false;
let selectedTx = -1;

const bitratePreset = {
  125:  {bit: 125,  btr0: 53, btr1: 2, prescaler: 1},
  250:  {bit: 250,  btr0: 27, btr1: 2, prescaler: 1},
  500:  {bit: 500,  btr0: 13, btr1: 2, prescaler: 1},
  1000: {bit: 1000, btr0: 4,  btr1: 1, prescaler: 1}
};

function $(id) {
  return document.getElementById(id);
}

function esc(v) {
  return String(v ?? '').replace(/[&<>"']/g, s => ({
    '&':'&amp;',
    '<':'&lt;',
    '>':'&gt;',
    '"':'&quot;',
    "'":'&#039;'
  }[s]));
}

function setPresetUi(value) {
  const p = bitratePreset[Number(value)] || bitratePreset[500];

  $('dbEntry').value = String(p.bit);
  $('bitRate').value = p.bit;
  $('btr0').value = p.btr0;
  $('btr1').value = p.btr1;
  $('sampleCount').value = '0';
  $('prescaler').value = p.prescaler;
}

async function postApi(path, params) {
  const res = await fetch(path, {
    method: 'POST',
    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
    body: params
  });

  const j = await res.json();

  $('connect').textContent = j.ok ? j.msg : 'ERR: ' + j.msg;
  $('connect').className = 'status ' + (j.ok ? 'ok' : 'err');

  return j;
}

async function applyConfig() {
  const p = new URLSearchParams();
  p.set('bitrate', $('dbEntry').value);

  $('cfgMsg').textContent = 'Đang đổi tốc độ CAN...';

  const j = await postApi('/api/config', p);

  if (j.ok) {
    userEditingConfig = false;
    setPresetUi(j.bitrate || $('dbEntry').value);
    $('cfgMsg').textContent = 'Đang dùng ' + (j.bitrate || $('dbEntry').value) + ' kBit/s';
  } else {
    $('cfgMsg').textContent = j.msg;
  }
}

function txDraftParams() {
  const type = $('txNewType').value;

  const p = new URLSearchParams();
  p.set('id', $('txNewId').value.trim());
  p.set('data', $('txNewData').value.trim());
  p.set('cycle', $('txNewCycle').value.trim());

  p.set('ext', type.indexOf('EXT') >= 0 ? '1' : '0');
  p.set('rtr', type.indexOf('RTR') >= 0 ? '1' : '0');

  return p;
}

function updateTxDraftDataState() {
  const type = $('txNewType').value;
  const isRtr = type.indexOf('RTR') >= 0;

  $('txNewData').disabled = isRtr;
  $('txNewData').placeholder = isRtr ? 'RTR không cần Data' : '01 00 00 00 00 00 00 00';
}

async function addTxRow() {
  const j = await postApi('/api/tx/add', txDraftParams());

  if (j.ok) {
    selectedTx = j.idx;
    poll(true);
  }
}

function txRowParams(idx) {
  const type = $('tx_type_' + idx).value;

  const p = new URLSearchParams();
  p.set('idx', idx);
  p.set('id', $('tx_id_' + idx).value.trim());
  p.set('data', $('tx_data_' + idx).value.trim());
  p.set('cycle', $('tx_cycle_' + idx).value.trim());

  p.set('ext', type.indexOf('EXT') >= 0 ? '1' : '0');
  p.set('rtr', type.indexOf('RTR') >= 0 ? '1' : '0');

  return p;
}

function setTxRowLock(idx, locked) {
  const ids = [
    'tx_type_' + idx,
    'tx_id_' + idx,
    'tx_data_' + idx,
    'tx_cycle_' + idx
  ];

  ids.forEach(id => {
    const e = $(id);
    if (e) e.disabled = locked;
  });
}

async function saveTxRow(idx) {
  const autoBox = $('tx_auto_' + idx);

  if (autoBox && autoBox.checked) {
    return;
  }

  const j = await postApi('/api/tx/update', txRowParams(idx));

  if (j.ok) {
    poll(true);
  }
}

async function sendSelectedTx() {
  if (selectedTx < 0) {
    $('connect').textContent = 'Chưa chọn message TX';
    $('connect').className = 'status err';
    return;
  }

  const p = new URLSearchParams();
  p.set('idx', selectedTx);

  const j = await postApi('/api/tx/send', p);

  if (j.ok) {
    poll(true);
  }
}

async function deleteSelectedTx() {
  if (selectedTx < 0) {
    $('connect').textContent = 'Chưa chọn message TX';
    $('connect').className = 'status err';
    return;
  }

  const p = new URLSearchParams();
  p.set('idx', selectedTx);

  const j = await postApi('/api/tx/delete', p);

  if (j.ok) {
    selectedTx = -1;
    poll(true);
  }
}

async function toggleTxAuto(idx, checkbox) {
  const enable = checkbox.checked;

  const p = txRowParams(idx);
  p.set('enable', enable ? '1' : '0');

  setTxRowLock(idx, enable);

  const j = await postApi('/api/tx/auto', p);

  if (!j.ok) {
    checkbox.checked = !enable;
    setTxRowLock(idx, !enable);
    return;
  }

  poll(true);
}

async function clearTx() {
  const j = await postApi('/api/clear_tx', new URLSearchParams());
  if (j.ok) {
    selectedTx = -1;
    poll(true);
  }
}

async function clearRx() {
  const j = await postApi('/api/clear_rx', new URLSearchParams());
  if (j.ok) {
    poll(true);
  }
}

function selectTxRow(idx) {
  selectedTx = idx;

  document.querySelectorAll('#txBody tr').forEach(tr => {
    tr.classList.remove('selected');
  });

  const tr = $('tx_tr_' + idx);
  if (tr) tr.classList.add('selected');
}

function renderTxRows(rows) {
  const body = $('txBody');

  if (!rows || rows.length === 0) {
    body.innerHTML = '<tr><td colspan="8" class="empty">Chưa có message TX</td></tr>';
    return;
  }

  body.innerHTML = rows.map(r => {
    const idx = r.idx;
    const auto = !!r.auto;
    const typeText = String(r.type || 'STD');

    const isExt = typeText.indexOf('EXT') >= 0;
    const isRtr = typeText.indexOf('RTR') >= 0;

    let typeValue = 'STD';
    if (isExt && isRtr) typeValue = 'EXT_RTR';
    else if (isExt) typeValue = 'EXT';
    else if (isRtr) typeValue = 'STD_RTR';

    const idValue = String(r.canid || '').replace(/h$/i, '');
    const selectedClass = Number(idx) === Number(selectedTx) ? 'selected' : '';

    return `
      <tr id="tx_tr_${idx}" class="${selectedClass}" onclick="selectTxRow(${idx})">
        <td>
          <select id="tx_type_${idx}" class="rowSelect"
                  ${auto ? 'disabled' : ''}
                  onfocus="editingTx=true"
                  onblur="editingTx=false"
                  onchange="editingTx=false; saveTxRow(${idx})">
            <option value="STD" ${typeValue === 'STD' ? 'selected' : ''}>STD</option>
            <option value="EXT" ${typeValue === 'EXT' ? 'selected' : ''}>EXT</option>
            <option value="STD_RTR" ${typeValue === 'STD_RTR' ? 'selected' : ''}>STD RTR</option>
            <option value="EXT_RTR" ${typeValue === 'EXT_RTR' ? 'selected' : ''}>EXT RTR</option>
          </select>
        </td>

        <td>
          <input id="tx_id_${idx}" class="rowInput rowId"
                 value="${esc(idValue)}"
                 ${auto ? 'disabled' : ''}
                 onfocus="editingTx=true"
                 onblur="editingTx=false; saveTxRow(${idx})">
        </td>

        <td>
          <input class="rowInput rowLen"
                 value="${esc(r.len)}"
                 disabled>
        </td>

        <td>
          <input class="rowInput"
                 value="${esc(r.name)}"
                 disabled>
        </td>

        <td>
          <input id="tx_data_${idx}" class="rowInput rowData"
                 value="${esc(r.data)}"
                 ${(auto || isRtr) ? 'disabled' : ''}
                 onfocus="editingTx=true"
                 onblur="editingTx=false; saveTxRow(${idx})">
        </td>

        <td>
          <input id="tx_cycle_${idx}" class="rowInput rowCycle"
                 type="number"
                 min="10"
                 value="${esc(r.cycle || 1000)}"
                 ${auto ? 'disabled' : ''}
                 onfocus="editingTx=true"
                 onblur="editingTx=false; saveTxRow(${idx})">
        </td>

        <td class="centerCell">
          <input id="tx_auto_${idx}"
                 type="checkbox"
                 ${auto ? 'checked' : ''}
                 onchange="toggleTxAuto(${idx}, this)">
        </td>

        <td>${esc(r.count)}</td>
      </tr>
    `;
  }).join('');
}

function renderRxRows(rows) {
  const body = $('rxBody');

  if (!rows || rows.length === 0) {
    body.innerHTML = '<tr><td colspan="7" class="empty">Chưa nhận được CAN frame</td></tr>';
    return;
  }

  body.innerHTML = rows.map(r => `
    <tr>
      <td>${esc(r.type)}</td>
      <td>${esc(r.canid)}</td>
      <td>${esc(r.len)}</td>
      <td>${esc(r.name)}</td>
      <td class="bytes">${esc(r.data)}</td>
      <td>${esc(r.cycle)}</td>
      <td>${esc(r.count)}</td>
    </tr>
  `).join('');
}

async function poll(onceOnly = false) {
  try {
    const res = await fetch('/api/state?t=' + Date.now(), {cache: 'no-store'});
    const j = await res.json();

    $('connect').textContent = 'Connected';
    $('connect').className = 'status ok';

    $('canState').textContent = 'CAN: ' + j.can;
    $('canState').className = 'status ' + (j.can === 'RUNNING' ? 'ok' : 'err');

    $('rxInfo').textContent = 'RX: ' + j.rxTotal;
    $('txInfo').textContent = 'TX: ' + j.txTotal;
    $('errInfo').textContent = 'ERR: TX ' + j.txErr + ' / RX ' + j.rxErr + ' / BUS ' + j.busErr + ' / MISS ' + j.rxMiss;

    $('ip').textContent = j.ip + ' | FW: ' + (j.fw || 'cũ (chưa nạp bản mới)');

    if (!userEditingConfig) {
      setPresetUi(j.bitrate || 500);
      $('cfgMsg').textContent = 'Đang dùng ' + (j.bitrate || 500) + ' kBit/s';
    }

    renderRxRows(j.rx);

    // đang sửa = con trỏ thực sự nằm trong một ô của bảng TX;
    // không tin cờ editingTx để bảng không bị kẹt nếu cờ quên reset
    const ae = document.activeElement;
    const editingRow = !!(ae && ae.id && ae.id.indexOf('tx_') === 0);

    if (!editingRow) {
      editingTx = false;
      renderTxRows(j.tx);
    }
  } catch (e) {
    $('connect').textContent = 'Disconnected';
    $('connect').className = 'status err';
  }

  if (!onceOnly) {
    setTimeout(poll, 400);
  }
}

updateTxDraftDataState();
poll();
</script>
</body>
</html>
)HTML";

// ================== HELPER ==================
bool argTrue(const String &s) {
  return s == "1" || s == "true" || s == "on" || s == "ON";
}

String frameName(uint32_t id, bool ext) {
  if (!ext && id == 0x336) return "";
  return "";
}

String hexId(uint32_t id, bool ext) {
  char buf[12];

  if (ext) {
    snprintf(buf, sizeof(buf), "%08lX", (unsigned long)id);
  } else {
    snprintf(buf, sizeof(buf), "%03lX", (unsigned long)id);
  }

  return String(buf);
}

String dataString(const uint8_t *data, uint8_t len, bool rtr) {
  if (rtr) return "RTR";

  String s;

  for (uint8_t i = 0; i < len; i++) {
    char b[4];
    snprintf(b, sizeof(b), "%02X", data[i]);

    if (i) s += " ";
    s += b;
  }

  return s;
}

const char *canStateName(twai_state_t s) {
  switch (s) {
    case TWAI_STATE_STOPPED:    return "STOPPED";
    case TWAI_STATE_RUNNING:    return "RUNNING";
    case TWAI_STATE_BUS_OFF:    return "BUS_OFF";
    case TWAI_STATE_RECOVERING: return "RECOVERING";
    default:                    return "UNKNOWN";
  }
}

void appendEscaped(String &out, const String &s) {
  for (size_t i = 0; i < s.length(); i++) {
    char c = s[i];

    if (c == '"' || c == '\\') {
      out += '\\';
      out += c;
    } else if (c == '\n') {
      out += "\\n";
    } else if (c == '\r') {
      out += "\\r";
    } else {
      out += c;
    }
  }
}

void jsonReply(bool ok, const String &msg) {
  String j;
  j.reserve(180 + msg.length());

  j += "{\"ok\":";
  j += ok ? "true" : "false";
  j += ",\"msg\":\"";
  appendEscaped(j, msg);
  j += "\"}";

  server.send(ok ? 200 : 400, "application/json; charset=utf-8", j);
}

void jsonReplyWithIdx(bool ok, const String &msg, int idx) {
  String j;
  j.reserve(220 + msg.length());

  j += "{\"ok\":";
  j += ok ? "true" : "false";
  j += ",\"msg\":\"";
  appendEscaped(j, msg);
  j += "\",\"idx\":";
  j += String(idx);
  j += "}";

  server.send(ok ? 200 : 400, "application/json; charset=utf-8", j);
}

void jsonReplyConfig(bool ok, const String &msg, uint32_t bitrate) {
  String j;
  j.reserve(240 + msg.length());

  j += "{\"ok\":";
  j += ok ? "true" : "false";
  j += ",\"msg\":\"";
  appendEscaped(j, msg);
  j += "\",\"bitrate\":";
  j += String(bitrate);
  j += "}";

  server.send(ok ? 200 : 400, "application/json; charset=utf-8", j);
}

int findSameRxRow(uint32_t id, bool ext, bool rtr) {
  for (int i = 0; i < MAX_RX_ROWS; i++) {
    if (rxRows[i].used &&
        rxRows[i].id == id &&
        rxRows[i].ext == ext &&
        rxRows[i].rtr == rtr) {
      return i;
    }
  }

  return -1;
}

int chooseRxRowSlot() {
  for (int i = 0; i < MAX_RX_ROWS; i++) {
    if (!rxRows[i].used) return i;
  }

  int oldest = 0;

  for (int i = 1; i < MAX_RX_ROWS; i++) {
    if (rxRows[i].lastMs < rxRows[oldest].lastMs) {
      oldest = i;
    }
  }

  return oldest;
}

// now = thời điểm frame được nhận (lấy ngay tại twai_receive, không phải lúc xử lý)
void updateRxRow(uint32_t id,
                 bool ext,
                 bool rtr,
                 uint8_t len,
                 const uint8_t *data,
                 uint32_t now) {
  xSemaphoreTake(rxMutex, portMAX_DELAY);

  int idx = findSameRxRow(id, ext, rtr);
  bool same = idx >= 0;

  if (!same) {
    idx = chooseRxRowSlot();
    memset(&rxRows[idx], 0, sizeof(CanRow));
  }

  CanRow &r = rxRows[idx];

  r.used = true;
  r.id = id;
  r.ext = ext;
  r.rtr = rtr;
  r.len = len;

  if (!rtr && data != nullptr) {
    memcpy(r.data, data, len);
  } else {
    memset(r.data, 0, sizeof(r.data));
  }

  if (same) {
    uint32_t delta = now - r.lastMs;

    // frame cùng ID đến trong cùng 1ms là burst: giữ nguyên chu kỳ
    // giữa các burst thay vì ghi đè bằng 0
    if (delta > 0) {
      r.cycleMs = delta;
    }

    r.count++;
  } else {
    r.cycleMs = 0;
    r.count = 1;
  }

  r.lastMs = now;
  rxTotal++;

  xSemaphoreGive(rxMutex);
}

bool isRowAuto(int idx) {
  for (int i = 0; i < MAX_AUTO_JOBS; i++) {
    if (txJobs[i].used && txJobs[i].rowIndex == idx) {
      return true;
    }
  }

  return false;
}

int findFreeTxRow() {
  for (int i = 0; i < MAX_ROWS; i++) {
    if (!txRows[i].used) return i;
  }

  return -1;
}

bool txIndexValid(int idx) {
  return idx >= 0 && idx < MAX_ROWS && txRows[idx].used;
}

int findAutoJobByRow(int idx) {
  for (int i = 0; i < MAX_AUTO_JOBS; i++) {
    if (txJobs[i].used && txJobs[i].rowIndex == idx) {
      return i;
    }
  }

  return -1;
}

int findFreeAutoJob() {
  for (int i = 0; i < MAX_AUTO_JOBS; i++) {
    if (!txJobs[i].used) return i;
  }

  return -1;
}

void stopAutoJobByRow(int idx) {
  for (int i = 0; i < MAX_AUTO_JOBS; i++) {
    if (txJobs[i].used && txJobs[i].rowIndex == idx) {
      txJobs[i].used = false;
    }
  }
}

// ================== PARSE ==================
bool parseHexUint(String raw, uint32_t &value) {
  raw.trim();

  if (raw.endsWith("h") || raw.endsWith("H")) {
    raw.remove(raw.length() - 1);
  }

  if (raw.startsWith("0x") || raw.startsWith("0X")) {
    raw = raw.substring(2);
  }

  if (raw.length() == 0) return false;

  char *endPtr = nullptr;
  value = strtoul(raw.c_str(), &endPtr, 16);

  return endPtr && *endPtr == '\0';
}

bool parseHexByte(String raw, uint8_t &value) {
  raw.trim();

  if (raw.startsWith("0x") || raw.startsWith("0X")) {
    raw = raw.substring(2);
  }

  if (raw.length() == 0 || raw.length() > 2) return false;

  char *endPtr = nullptr;
  uint32_t v = strtoul(raw.c_str(), &endPtr, 16);

  if (!endPtr || *endPtr != '\0' || v > 0xFF) return false;

  value = (uint8_t)v;
  return true;
}

bool parseDataBytes(String raw, uint8_t *data, uint8_t &len, String &err) {
  len = 0;
  raw.trim();

  if (raw.length() == 0) {
    return true;
  }

  raw.replace(",", " ");
  raw.replace(";", " ");
  raw.replace("\n", " ");
  raw.replace("\r", " ");

  bool hasSpace = raw.indexOf(' ') >= 0;

  if (hasSpace) {
    int pos = 0;

    while (pos < raw.length()) {
      int next = raw.indexOf(' ', pos);

      if (next < 0) {
        next = raw.length();
      }

      String token = raw.substring(pos, next);
      token.trim();

      if (token.length() > 0) {
        if (len >= 8) {
          err = "Data vượt quá 8 byte";
          return false;
        }

        uint8_t b;

        if (!parseHexByte(token, b)) {
          err = "Byte data không hợp lệ: " + token;
          return false;
        }

        data[len++] = b;
      }

      pos = next + 1;
    }

    return true;
  }

  raw.replace("0x", "");
  raw.replace("0X", "");

  if (raw.length() % 2) {
    raw = "0" + raw;
  }

  if (raw.length() > 16) {
    err = "Data vượt quá 8 byte";
    return false;
  }

  for (int i = 0; i < raw.length(); i += 2) {
    uint8_t b;
    String token = raw.substring(i, i + 2);

    if (!parseHexByte(token, b)) {
      err = "Data không hợp lệ";
      return false;
    }

    data[len++] = b;
  }

  return true;
}

bool readFrameArgs(uint32_t &id,
                   bool &ext,
                   bool &rtr,
                   uint8_t &len,
                   uint8_t *data,
                   String &err) {
  if (!server.hasArg("id")) {
    err = "Thiếu CAN-ID";
    return false;
  }

  if (!parseHexUint(server.arg("id"), id)) {
    err = "CAN-ID không hợp lệ";
    return false;
  }

  ext = argTrue(server.arg("ext"));
  rtr = argTrue(server.arg("rtr"));

  if (!ext && id > 0x7FF) {
    err = "Standard ID phải <= 7FFh";
    return false;
  }

  if (ext && id > 0x1FFFFFFF) {
    err = "Extended ID phải <= 1FFFFFFFh";
    return false;
  }

  memset(data, 0, 8);

  if (rtr) {
    len = 0;
    return true;
  }

  return parseDataBytes(server.arg("data"), data, len, err);
}

bool updateTxRowFromArgs(int idx, bool resetCount, String &err) {
  uint32_t id;
  bool ext;
  bool rtr;
  uint8_t len;
  uint8_t data[8];

  if (!readFrameArgs(id, ext, rtr, len, data, err)) {
    return false;
  }

  uint32_t cycle = (uint32_t)server.arg("cycle").toInt();

  if (cycle < 10) {
    cycle = 1000;
  }

  txRows[idx].used = true;
  txRows[idx].id = id;
  txRows[idx].ext = ext;
  txRows[idx].rtr = rtr;
  txRows[idx].len = len;
  txRows[idx].cycleMs = cycle;
  txRows[idx].lastMs = millis();

  if (!rtr) {
    memcpy(txRows[idx].data, data, len);
  } else {
    memset(txRows[idx].data, 0, sizeof(txRows[idx].data));
  }

  if (resetCount) {
    txRows[idx].count = 0;
  }

  return true;
}

// ================== CAN ==================
twai_timing_config_t getTimingConfig(uint32_t kbps) {
  switch (kbps) {
    case 125:
      return TWAI_TIMING_CONFIG_125KBITS();

    case 250:
      return TWAI_TIMING_CONFIG_250KBITS();

    case 1000:
      return TWAI_TIMING_CONFIG_1MBITS();

    case 500:
    default:
      return TWAI_TIMING_CONFIG_500KBITS();
  }
}

bool startCan(uint32_t bitrate) {
  twai_general_config_t g_config =
    TWAI_GENERAL_CONFIG_DEFAULT(CAN_TX_GPIO, CAN_RX_GPIO, TWAI_MODE_NORMAL);

  g_config.tx_queue_len = 20;
  g_config.rx_queue_len = 50;

  twai_timing_config_t t_config = getTimingConfig(bitrate);
  twai_filter_config_t f_config = TWAI_FILTER_CONFIG_ACCEPT_ALL();

  esp_err_t result;

  result = twai_driver_install(&g_config, &t_config, &f_config);

  if (result != ESP_OK) {
    Serial.print("twai_driver_install failed: ");
    Serial.println((int)result);
    return false;
  }

  result = twai_start();

  if (result != ESP_OK) {
    Serial.print("twai_start failed: ");
    Serial.println((int)result);
    twai_driver_uninstall();
    return false;
  }

  currentBitrate = bitrate;
  return true;
}

void stopCan() {
  if (!canReady) return;

  canReady = false;

  // chờ task RX thoát khỏi twai_receive (tối đa ~50ms) trước khi gỡ driver
  while (rxTaskBusy) {
    vTaskDelay(pdMS_TO_TICKS(1));
  }

  twai_stop();
  twai_driver_uninstall();
}

bool restartCan(uint32_t bitrate) {
  stopCan();
  delay(20);

  canReady = startCan(bitrate);
  return canReady;
}

bool transmitFrame(const CanRow &r, String &err) {
  if (!canReady) {
    err = "CAN chưa khởi động";
    return false;
  }

  twai_message_t msg = {};
  msg.identifier = r.id;
  msg.data_length_code = r.len;
  msg.flags = 0;

  if (r.ext) {
    msg.flags |= TWAI_MSG_FLAG_EXTD;
  }

  if (r.rtr) {
    msg.flags |= TWAI_MSG_FLAG_RTR;
  }

  if (!r.rtr && r.len > 0) {
    memcpy(msg.data, r.data, r.len);
  }

  esp_err_t result = twai_transmit(&msg, pdMS_TO_TICKS(20));

  if (result != ESP_OK) {
    err = "twai_transmit lỗi: " + String((int)result);
    return false;
  }

  txTotal++;
  return true;
}

bool sendTxRow(int idx, uint32_t forcedCycleMs, String &err) {
  if (!txIndexValid(idx)) {
    err = "TX row không hợp lệ";
    return false;
  }

  if (!transmitFrame(txRows[idx], err)) {
    return false;
  }

  txRows[idx].count++;
  txRows[idx].lastMs = millis();

  if (forcedCycleMs > 0) {
    txRows[idx].cycleMs = forcedCycleMs;
  }

  return true;
}

// Task nhận CAN riêng: block trên twai_receive nên timestamp lấy được
// ngay khi frame đến, không phụ thuộc độ trễ của loop()/web server.
void canRxTask(void *arg) {
  twai_message_t msg;

  for (;;) {
    // rxTaskBusy phải bật TRƯỚC khi kiểm tra canReady để stopCan()
    // không uninstall driver trong lúc twai_receive đang chạy
    rxTaskBusy = true;

    if (!canReady) {
      rxTaskBusy = false;
      vTaskDelay(pdMS_TO_TICKS(50));
      continue;
    }

    esp_err_t res = twai_receive(&msg, pdMS_TO_TICKS(50));

    rxTaskBusy = false;

    if (res != ESP_OK) continue;

    uint32_t now = millis();

    bool ext = msg.flags & TWAI_MSG_FLAG_EXTD;
    bool rtr = msg.flags & TWAI_MSG_FLAG_RTR;

    uint8_t len = msg.data_length_code;

    if (len > 8) {
      len = 8;
    }

    updateRxRow(msg.identifier, ext, rtr, len, msg.data, now);
  }
}

void processAutoTx() {
  if (!canReady) return;

  uint32_t now = millis();

  for (int i = 0; i < MAX_AUTO_JOBS; i++) {
    if (!txJobs[i].used) continue;

    int idx = txJobs[i].rowIndex;

    if (!txIndexValid(idx)) {
      txJobs[i].used = false;
      continue;
    }

    if ((int32_t)(now - txJobs[i].nextMs) >= 0) {
      String err;
      sendTxRow(idx, txJobs[i].intervalMs, err);

      txJobs[i].nextMs += txJobs[i].intervalMs;

      if ((int32_t)(now - txJobs[i].nextMs) >= 0) {
        txJobs[i].nextMs = now + txJobs[i].intervalMs;
      }
    }
  }
}

// ================== JSON ==================
void appendRowJson(String &j, const CanRow &r, bool isTx, int idx) {
  j += "{";

  j += "\"idx\":";
  j += String(idx);
  j += ",";

  j += "\"type\":\"";
  if (r.ext) j += "EXT";
  else       j += "STD";
  if (r.rtr) j += " RTR";
  j += "\",";

  j += "\"canid\":\"";
  j += hexId(r.id, r.ext);
  j += "h\",";

  j += "\"len\":";
  j += String(r.len);
  j += ",";

  j += "\"name\":\"";
  appendEscaped(j, frameName(r.id, r.ext));
  j += "\",";

  j += "\"data\":\"";
  appendEscaped(j, dataString(r.data, r.len, r.rtr));
  j += "\",";

  j += "\"cycle\":";
  j += String(r.cycleMs);
  j += ",";

  if (isTx) {
    j += "\"auto\":";
    j += isRowAuto(idx) ? "true" : "false";
    j += ",";
  }

  j += "\"count\":";
  j += String(r.count);

  j += "}";
}

// ================== API ==================
void handleRoot() {
  server.send_P(200, "text/html; charset=utf-8", INDEX_HTML);
}

void handleState() {
  String canState = "NOT_READY";

  uint32_t txErr = 0;
  uint32_t rxErr = 0;
  uint32_t busErr = 0;
  uint32_t rxMiss = 0;

  if (canReady) {
    twai_status_info_t st;

    if (twai_get_status_info(&st) == ESP_OK) {
      canState = canStateName(st.state);
      txErr = st.tx_error_counter;
      rxErr = st.rx_error_counter;
      busErr = st.bus_error_count;
      rxMiss = st.rx_missed_count;
    }
  }

  String j;
  j.reserve(32000);

  j += "{";

  j += "\"ok\":true,";

  j += "\"ip\":\"";
  j += WiFi.softAPIP().toString();
  j += "\",";

  j += "\"fw\":\"";
  j += __DATE__ " " __TIME__;
  j += "\",";

  j += "\"can\":\"";
  j += canState;
  j += "\",";

  j += "\"bitrate\":";
  j += String(currentBitrate);
  j += ",";

  j += "\"rxTotal\":";
  j += String(rxTotal);
  j += ",";

  j += "\"txTotal\":";
  j += String(txTotal);
  j += ",";

  j += "\"txErr\":";
  j += String(txErr);
  j += ",";

  j += "\"rxErr\":";
  j += String(rxErr);
  j += ",";

  j += "\"busErr\":";
  j += String(busErr);
  j += ",";

  j += "\"rxMiss\":";
  j += String(rxMiss);
  j += ",";

  j += "\"tx\":[";
  bool first = true;

  for (int i = 0; i < MAX_ROWS; i++) {
    if (!txRows[i].used) continue;

    if (!first) j += ",";
    appendRowJson(j, txRows[i], true, i);
    first = false;
  }

  j += "],";

  j += "\"rx\":[";
  first = true;

  xSemaphoreTake(rxMutex, portMAX_DELAY);

  for (int i = 0; i < MAX_RX_ROWS; i++) {
    if (!rxRows[i].used) continue;

    if (!first) j += ",";
    appendRowJson(j, rxRows[i], false, i);
    first = false;
  }

  xSemaphoreGive(rxMutex);

  j += "]";

  j += "}";

  server.send(200, "application/json; charset=utf-8", j);
}

void handleConfig() {
  uint32_t bitrate = (uint32_t)server.arg("bitrate").toInt();

  if (!(bitrate == 125 || bitrate == 250 || bitrate == 500 || bitrate == 1000)) {
    jsonReplyConfig(false, "Bitrate không hợp lệ", currentBitrate);
    return;
  }

  if (restartCan(bitrate)) {
    jsonReplyConfig(true, "Đã đổi tốc độ CAN", currentBitrate);
  } else {
    jsonReplyConfig(false, "Đổi tốc độ CAN thất bại", currentBitrate);
  }
}

void handleTxAdd() {
  int idx = findFreeTxRow();

  if (idx < 0) {
    jsonReply(false, "Bảng TX đã đầy");
    return;
  }

  memset(&txRows[idx], 0, sizeof(CanRow));

  String err;

  if (!updateTxRowFromArgs(idx, true, err)) {
    memset(&txRows[idx], 0, sizeof(CanRow));
    jsonReply(false, err);
    return;
  }

  jsonReplyWithIdx(true, "Đã thêm message TX", idx);
}

void handleTxUpdate() {
  if (!server.hasArg("idx")) {
    jsonReply(false, "Thiếu idx");
    return;
  }

  int idx = server.arg("idx").toInt();

  if (!txIndexValid(idx)) {
    jsonReply(false, "TX row không hợp lệ");
    return;
  }

  if (isRowAuto(idx)) {
    jsonReply(false, "Message đang Auto, bỏ tích Auto trước khi sửa");
    return;
  }

  String err;

  if (!updateTxRowFromArgs(idx, true, err)) {
    jsonReply(false, err);
    return;
  }

  jsonReply(true, "Đã lưu message TX");
}

void handleTxSend() {
  if (!server.hasArg("idx")) {
    jsonReply(false, "Thiếu idx");
    return;
  }

  int idx = server.arg("idx").toInt();
  String err;

  if (!sendTxRow(idx, 0, err)) {
    jsonReply(false, err);
    return;
  }

  jsonReply(true, "Đã gửi message TX");
}

void handleTxDelete() {
  if (!server.hasArg("idx")) {
    jsonReply(false, "Thiếu idx");
    return;
  }

  int idx = server.arg("idx").toInt();

  if (!txIndexValid(idx)) {
    jsonReply(false, "TX row không hợp lệ");
    return;
  }

  if (isRowAuto(idx)) {
    jsonReply(false, "Message đang Auto, bỏ tích Auto trước khi xóa");
    return;
  }

  memset(&txRows[idx], 0, sizeof(CanRow));

  jsonReply(true, "Đã xóa message TX");
}

void handleTxAuto() {
  if (!server.hasArg("idx")) {
    jsonReply(false, "Thiếu idx");
    return;
  }

  int idx = server.arg("idx").toInt();

  if (!txIndexValid(idx)) {
    jsonReply(false, "TX row không hợp lệ");
    return;
  }

  bool enable = argTrue(server.arg("enable"));

  if (enable) {
    if (isRowAuto(idx)) {
      jsonReply(true, "Auto TX đang bật");
      return;
    }

    String err;

    if (!updateTxRowFromArgs(idx, false, err)) {
      jsonReply(false, err);
      return;
    }

    if (txRows[idx].cycleMs < 10) {
      jsonReply(false, "Cycle tối thiểu 10 ms");
      return;
    }

    int slot = findFreeAutoJob();

    if (slot < 0) {
      jsonReply(false, "Đã đầy danh sách Auto TX");
      return;
    }

    txJobs[slot].used = true;
    txJobs[slot].rowIndex = idx;
    txJobs[slot].intervalMs = txRows[idx].cycleMs;
    txJobs[slot].nextMs = millis() + txRows[idx].cycleMs;

    if (!sendTxRow(idx, txRows[idx].cycleMs, err)) {
      txJobs[slot].used = false;
      jsonReply(false, err);
      return;
    }

    jsonReply(true, "Đã bật Auto TX");
  } else {
    stopAutoJobByRow(idx);
    jsonReply(true, "Đã tắt Auto TX");
  }
}

void handleClearTx() {
  memset(txRows, 0, sizeof(txRows));
  memset(txJobs, 0, sizeof(txJobs));

  txTotal = 0;

  jsonReply(true, "Đã clear TX");
}

void handleClearRx() {
  xSemaphoreTake(rxMutex, portMAX_DELAY);

  memset(rxRows, 0, sizeof(rxRows));
  rxTotal = 0;

  xSemaphoreGive(rxMutex);

  jsonReply(true, "Đã clear RX");
}

// ================== SETUP / LOOP ==================
void setup() {
  Serial.begin(115200);
  delay(800);

  Serial.println();
  Serial.println("======================================");
  Serial.println("ESP32-S3 CAN Webserver starting...");
  Serial.printf("Build: %s %s\n", __DATE__, __TIME__);
  Serial.println("======================================");

  Serial.printf("Flash size: %lu MB\n",
                (unsigned long)(ESP.getFlashChipSize() / (1024 * 1024)));

  Serial.printf("PSRAM found: %s\n",
                psramFound() ? "YES" : "NO");

  Serial.printf("PSRAM size: %lu MB\n",
                (unsigned long)(ESP.getPsramSize() / (1024 * 1024)));

  Serial.printf("CAN RX GPIO: %d\n", CAN_RX_PIN);
  Serial.printf("CAN TX GPIO: %d\n", CAN_TX_PIN);

  rxMutex = xSemaphoreCreateMutex();

  canReady = startCan(currentBitrate);

  if (canReady) {
    Serial.println("CAN/TWAI started OK");
  } else {
    Serial.println("CAN/TWAI start FAILED");
  }

  // Task nhận CAN chạy trên core 0 (loop Arduino chạy core 1)
  xTaskCreatePinnedToCore(canRxTask, "canRx", 4096, nullptr, 10, nullptr, 0);

  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID, AP_PASS);

  Serial.println();
  Serial.print("WiFi AP SSID: ");
  Serial.println(AP_SSID);

  Serial.print("WiFi AP PASS: ");
  Serial.println(AP_PASS);

  Serial.print("Open browser: http://");
  Serial.println(WiFi.softAPIP());

  server.on("/", HTTP_GET, handleRoot);
  server.on("/api/state", HTTP_GET, handleState);
  server.on("/api/config", HTTP_POST, handleConfig);

  server.on("/api/tx/add", HTTP_POST, handleTxAdd);
  server.on("/api/tx/update", HTTP_POST, handleTxUpdate);
  server.on("/api/tx/send", HTTP_POST, handleTxSend);
  server.on("/api/tx/delete", HTTP_POST, handleTxDelete);
  server.on("/api/tx/auto", HTTP_POST, handleTxAuto);

  server.on("/api/clear_tx", HTTP_POST, handleClearTx);
  server.on("/api/clear_rx", HTTP_POST, handleClearRx);

  server.begin();

  Serial.println("HTTP server started");
  Serial.println("======================================");
}

void loop() {
  server.handleClient();
  processAutoTx();

  delay(1);
}